<?php

/**
 * @author Dau Ngoc Huy - huydaungoc@gmail.com - anhxtanh3087
 */
class Layout {

	public static function beforeRenderView($layout, $layoutPath, View $view, Controller $controller) {
		
	}

	public static function afterRenderView($layout, $layoutPath, View $view, Controller $controller) {//ten cu la: run
		
	}

}
