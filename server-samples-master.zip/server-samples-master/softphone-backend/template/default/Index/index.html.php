<!DOCTYPE html>
<html>
	<head>
		<title>Ke toan tai chinh</title>
		
	</head>
	<frameset cols="15%, 85%">
		<frame name="left" src="index/menu" />
		<frame name="center" src="socai" />
		<noframes>
			<body>
				Your browser does not support frames.
			</body>
		</noframes>
	</frameset>
</html>
