<!DOCTYPE html>
<html>
	<head>
		<title>Ke toan tai chinh</title>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
	</head>

	<body>
		<div>
			
			<h3>Công ty cổ phần Firsoft</h3>
			
			<br /><br />

			<a href="<?=BASE_URL?>socai" target="center">Sổ cái - Tổng hợp</a> <br /><br />
			
			<a href="<?=BASE_URL?>hr/index" target="center">Nhân sự</a> <br /><br />
			
			<a href="<?=BASE_URL?>bank/index" target="center">Ngân hàng</a> <br /><br />
			
			<a href="<?=BASE_URL?>cashfund/index" target="center">Quỹ tiền mặt</a> <br /><br />

			<a href="<?=BASE_URL?>buy/index" target="center">Khoản chi - Mua vào</a> <br /><br />
			
			<a href="<?=BASE_URL?>thu/index" target="center">Khoản thu - Bán ra</a> <br /><br />
			
			
			<a href="<?=BASE_URL?>customer/index" target="center">Khách hàng</a> <br /><br />
			
			<a href="<?=BASE_URL?>contract/index" target="center">Hợp đồng</a> <br /><br />
			
			
			
			
			
			
			<br /><br /><br /><br /><br /><br />
			<a href="<?=BASE_URL?>user/logout" target="center">Đăng xuất</a> <br /><br />
			<a href="<?=BASE_URL?>user/changepassword" target="center">Đổi mật khẩu</a> <br /><br />

		</div>
	</body>
</html>
